The purpose of this small app is to lock/unlock the 'game.cfg' and 'persistedsettings.json' files in your C:\Riot Games\Config\ directory, which will force your settings from one account to another.

To use: 
- Log into one account you want to move settings FROM, play a game / use practice tool so that game stores settings into the local files
- Open this app and press 'Lock Settings'. 
- Log into other account and queue into your match and your settings should be copied. 

You can then unlock your settings and tweak as needed. 